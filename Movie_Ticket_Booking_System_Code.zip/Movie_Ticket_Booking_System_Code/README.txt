Click on the exe files to run the code
Prerequisites: python along with sql connector extension of python should be installed
Ensure strong internet connection otherwise exe will be slow